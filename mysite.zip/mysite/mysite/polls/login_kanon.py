

from django.contrib.auth.models import User
class login_kanon(User):
		def login_kanon_def():
			user = User.objects.all().values()
			
			